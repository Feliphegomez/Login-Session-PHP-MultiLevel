<?php 
 
class Mailer
{
   /**
    * sendWelcome - Envía un mensaje de bienvenida al usuario
	* recién registrado, suministrando también el nombre de usuario y contraseña.
    */
   function sendWelcome($user, $email, $pass){
      $from = "From: ".EMAIL_FROM_NAME." <".EMAIL_FROM_ADDR.">";
      $subject = "CMS-DM - Bienvenido!";
      $body = $user.",\n\n"
             ."Bienvenido! Usted a sido  registrado a un sitio CMS-DM "
             ."con la siguiente información:\n\n"
             ."Usuario: ".$user."\n"
             ."Clave de Acceso: ".$pass."\n\n"
             ."Si alguna vez pierde u olvida su contraseña, una nueva "
             ."contraseña será generada para usted y enviado a esta "
             ."dirección de correo electrónico, si desea cambiar "
             ."su dirección de correo electrónico, puede hacerlo "
             ."dirigiéndose a la página de mi cuenta después de iniciar sesión.\n\n"
             ."- CMS-DM";

      return mail($email,$subject,$body,$from);
   }
   
   /**
    * sendNewPass - Envía la nueva contraseña generada a la
	* dirección de correo electrónico del usuario que se especificó
	* al registrarse.
    */
   function sendNewPass($user, $email, $pass){
      $from = "From: ".EMAIL_FROM_NAME." <".EMAIL_FROM_ADDR.">";
      $subject = "CMS-DM - Tu nueva contraseña";
      $body = $user.",\n\n"
             ."Hemos generado una nueva contraseña para usted "
             ."a petición del cliente, puede utilizar esta nueva "
             ."contraseña con su nombre de usuario para iniciar sesión en CMS-DM.\n\n"
             ."Usuario: ".$user."\n"
             ."Nueva Clave de Acceso: ".$pass."\n\n"
             ."Se recomienda que cambie su contraseña "
             ."a algo que es más fácil de recordar, se  "
             ."puede hacer por ir a la página de mi "
             ."cuenta después de iniciar sesión.\n\n"
             ."- CMS-DM";
             
      return mail($email,$subject,$body,$from);
   }
};

/* Inicializar Envio de Correo */
$mailer = new Mailer;
 
?>
