<?php
if(!defined('TBL_ACTIVE_USERS')) {
  die("Error al procesar la página");
}

$q = "SELECT username FROM ".TBL_ACTIVE_USERS
    ." ORDER BY timestamp DESC,username";
$result = $database->query($q);
/* Ha producido un error, de retorno dado nombre por defecto */
$num_rows = mysql_numrows($result);
if(!$result || ($num_rows < 0)){
   echo "Error info";
}
else if($num_rows > 0){
   /* Mostrar usuarios activos, con enlace a su información */
   echo "<table align=\"left\" border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n";
   echo "<tr><td><font size=\"2\">\n";
   for($i=0; $i<$num_rows; $i++){
      $uname = mysql_result($result,$i,"username");

      echo "<a href=\"userinfo.php?user=$uname\">$uname</a> / ";
   }
   echo "</font></td></tr></table><br>\n";
}
?>
