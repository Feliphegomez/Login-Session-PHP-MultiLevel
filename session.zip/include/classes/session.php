<?php
include("database.php");
include("mailer.php");
include("form.php");

class Session
{
   var $username;     //Nombre de usuario dado de inscripción
   var $userid;       //valor aleatorio generado en el inicio de sesión actual
   var $userlevel;    //El nivel al que corresponde el usuario
   var $time;         //vez que el usuario ha sido activado (página cargada)
   var $logged_in;    //el usuario ha iniciado sesión
   var $userinfo = array();  //El arreglo que contiene toda la información de usuario
   var $url;          //The page url current being viewed
   var $referrer;     //Última página web registrada vista
   
   
   /* Class constructor */
   function Session(){
      $this->time = time();
      $this->startSession();
   }

   /**
    * startSession - Lleva a cabo todas las acciones necesarias para
	* inicializar el objeto de sesión. Trata de determinar si el
	* usuario ha iniciado la sesión ya, y establece las variables
	* necesarias. También se aprovecha de esta carga de la página
	* para actualizar las tablas de visitantes activos.
    */
   function startSession(){
      global $database;  //La conexión de base de datos
      session_start();   //Dile a PHP para que comience las sesiones

      /* Determinar si el usuario ha iniciado sesión */
      $this->logged_in = $this->checkLogin();

      /**
       * Valor seleccionado de invitados a los usuarios no registrados,
	   * y actualización de tabla de clientes activos en consecuencia.
       */
      if(!$this->logged_in){
         $this->username = $_SESSION['username'] = GUEST_NAME;
         $this->userlevel = GUEST_LEVEL;
         $database->addActiveGuest($_SERVER['REMOTE_ADDR'], $this->time);
      }
      /* Actualizar última marca de tiempo activo*/
      else{
         $database->addActiveUser($this->username, $this->time);
      }
      
      /* Retire los visitantes inactivos de de base de datos */
      $database->removeInactiveUsers();
      $database->removeInactiveGuests();
      
      /* Referencia de pagina */
      if(isset($_SESSION['url'])){
         $this->referrer = $_SESSION['url'];
      }else{
         $this->referrer = "/";
      }

      /* Establecer URL actual */
      $this->url = $_SESSION['url'] = $_SERVER['PHP_SELF'];
   }

   /**
    * checkLogin - Comprueba si el usuario ya ha iniciado una sesión previamente,
	* y ya se ha establecido una sesión con el usuario. También comprueba si el usuario
	* ha recordado. Si es así, la base de datos se consulta para asegurarse de la
	* autenticidad del usuario. Devuelve true si el usuario ha iniciado sesión.
    */
   function checkLogin(){
      global $database;  //La conexión de base de datos
      /* Compruebe si el usuario se ha recordado */
      if(isset($_COOKIE['cookname']) && isset($_COOKIE['cookid'])){
         $this->username = $_SESSION['username'] = $_COOKIE['cookname'];
         $this->userid   = $_SESSION['userid']   = $_COOKIE['cookid'];
      }

      /* Nombre de usuario y ID de usuario se han establecido y no invitados */
      if(isset($_SESSION['username']) && isset($_SESSION['userid']) &&
         $_SESSION['username'] != GUEST_NAME){
         /* Confirman que el nombre de usuario y ID de usuario son válidas */
         if($database->confirmUserID($_SESSION['username'], $_SESSION['userid']) != 0){
            /* Las variables son incorrectos, el usuario no se ha identificado en */
            unset($_SESSION['username']);
            unset($_SESSION['userid']);
            return false;
         }

         /* El usuario se registra en las variables de clase, establecidos */
         $this->userinfo  = $database->getUserInfo($_SESSION['username']);
         $this->username  = $this->userinfo['username'];
         $this->userid    = $this->userinfo['userid'];
         $this->userlevel = $this->userinfo['userlevel'];
         return true;
      }
      /* El usuario no  esta registrado */
      else{
         return false;
      }
   }

   /**
    * login - The user has submitted his username and password
    * through the login form, this function checks the authenticity
    * of that information in the database and creates the session.
    * Effectively logging in the user if all goes well.
    */
   function login($subuser, $subpass, $subremember){
      global $database, $form;  //La base de datos y objeto de formulario

      /* la comprobación de errores */
      $field = "user";  //Use field name for username
      if(!$subuser || strlen($subuser = trim($subuser)) == 0){
         $form->setError($field, "* Username not entered");
      }
      else{
         /* Compruebe si el nombre no es alfanumérico */
         if(!eregi("^([0-9a-z])*$", $subuser)){
            $form->setError($field, "* Username not alphanumeric");
         }
      }

      /* la comprobación de errores de contraseña */
      $field = "pass";  //Utilice el nombre del campo de contraseña
      if(!$subpass){
         $form->setError($field, "* Password not entered");
      }
      
      /* Volver si existen errores de formulario */
      if($form->num_errors > 0){
         return false;
      }

      /* Comprueba que el nombre de usuario está en de base de datos y la contraseña es correcta */
      $subuser = stripslashes($subuser);
      $result = $database->confirmUserPass($subuser, md5($subpass));

      /* Consulte los códigos de error */
      if($result == 1){
         $field = "user";
         $form->setError($field, "* Username not found");
      }
      else if($result == 2){
         $field = "pass";
         $form->setError($field, "* Invalid password");
      }
      
      /* Volver si existen errores de forma */
      if($form->num_errors > 0){
         return false;
      }

      /* Nombre de usuario y la contraseña correcta, regístrese variables de sesión */
      $this->userinfo  = $database->getUserInfo($subuser);
      $this->username  = $_SESSION['username'] = $this->userinfo['username'];
      $this->userid    = $_SESSION['userid']   = $this->generateRandID();
      $this->userlevel = $this->userinfo['userlevel'];
      
      /* Inserte userid en de base de datos y actualizar la tabla usuarios activos */
      $database->updateUserField($this->username, "userid", $this->userid);
      $database->addActiveUser($this->username, $this->time);
      $database->removeActiveGuest($_SERVER['REMOTE_ADDR']);

      /**
       * Esta es la parte buena: el usuario ha solicitado que recordemos que ha iniciado
	   * la sesión, por lo que establecer dos galletas. Una para sujetar su nombre de
	   * usuario y una para sujetar a su valor de identificador de usuario al azar.
	   * De que caduque el tiempo especificado en constants.php. Ahora, la próxima vez
	   * que viene a nuestro sitio, lo vamos a conectarse de forma automática, pero sólo
	   * si él no cerrar la sesión antes de marcharse.
       */
      if($subremember){
         setcookie("cookname", $this->username, time()+COOKIE_EXPIRE, COOKIE_PATH);
         setcookie("cookid",   $this->userid,   time()+COOKIE_EXPIRE, COOKIE_PATH);
      }

      /* Inicio de sesión completado con éxito */
      return true;
   }

   /**
    * logout - Se llama cuando el usuario quiere, debe estar desconectado de la página web.
	* Borra todas las cookies que se quedarán almacenadas en el ordenador del usuario como
	* resultado de lo que quiera ser recordado, y también lo elimina variables de sesión y
	* degrada su nivel de usuario invitado.
    */
   function logout(){
      global $database;  //La conexión de base de datos
      /**
       * Delete cookies - El tiempo debe es siemrpe en el pasado, por lo
	   * que sólo niega lo que ha añadido al crear la cookie.
       */
      if(isset($_COOKIE['cookname']) && isset($_COOKIE['cookid'])){
         setcookie("cookname", "", time()-COOKIE_EXPIRE, COOKIE_PATH);
         setcookie("cookid",   "", time()-COOKIE_EXPIRE, COOKIE_PATH);
      }

      /* sin establecer las variables de sesión de PHP */
      unset($_SESSION['username']);
      unset($_SESSION['userid']);

      /* Reflejar que el usuario ha cerrado la sesión */
      $this->logged_in = false;
      
      /**
       * Sacar de la tabla usuarios activos y añadir a las tablas huéspedes activos.
       */
      $database->removeActiveUser($this->username);
      $database->addActiveGuest($_SERVER['REMOTE_ADDR'], $this->time);
      
      /* Set user level to guest */
      $this->username  = GUEST_NAME;
      $this->userlevel = GUEST_LEVEL;
   }

   /**
    * register - Se llama cuando el usuario acaba de presentar el formulario de inscripción.
	* Determina si hubo algún error con los campos de entrada, si es así, registra los
	* errores y devuelve 1. Si no se encuentran errores, se registra el nuevo usuario y devuelve 0.
	* devuelve 2 si el registro ha fallado.
    */
   function register($subuser, $subpass, $subemail){
      global $database, $form, $mailer;  //La base de datos, el formulario y el objeto del correo
      
      /* la comprobación de errores */
      $field = "user";  //Use field name for username
      if(!$subuser || strlen($subuser = trim($subuser)) == 0){
         $form->setError($field, "* Username not entered");
      }
      else{
         /* Arreglar nombre de usuario, revisar longitud */
         $subuser = stripslashes($subuser);
         if(strlen($subuser) < 5){
            $form->setError($field, "* Username below 5 characters");
         }
         else if(strlen($subuser) > 30){
            $form->setError($field, "* Username above 30 characters");
         }
         /* Compruebe si el nombre no es alfanumérico */
         else if(!eregi("^([0-9a-z_])+$", $subuser)){
            $form->setError($field, "* Username not alphanumeric");
         }
         /* Compruebe si está reservado el nombre de usuario */
         else if(strcasecmp($subuser, GUEST_NAME) == 0){
            $form->setError($field, "* Username reserved word");
         }
         /* Compruebe si el nombre ya está en uso */
         else if($database->usernameTaken($subuser)){
            $form->setError($field, "* Username already in use");
         }
         /* Compruebe si está prohibido el usuario */
         else if($database->usernameBanned($subuser)){
            $form->setError($field, "* Username banned");
         }
      }

      /* la comprobación de errores de contraseña */
      $field = "pass";  //Utilice el nombre del campo de contraseña
      if(!$subpass){
         $form->setError($field, "* Password not entered");
      }
      else{
         /* Arreglar contraseña, y marca la longitud*/
         $subpass = stripslashes($subpass);
         if(strlen($subpass) < 4){
            $form->setError($field, "* Password too short");
         }
         /* Compruebe si la contraseña no es alfanumérico */
         else if(!eregi("^([0-9a-z])+$", ($subpass = trim($subpass)))){
            $form->setError($field, "* Password not alphanumeric");
         }
         /**
          * Note: I trimmed the password only after I checked the length
          * because if you fill the password field up with spaces
          * it looks like a lot more characters than 4, so it looks
          * kind of stupid to report "password too short".
          */
      }
      
      /* Email error checking */
      $field = "email";  //Use field name for email
      if(!$subemail || strlen($subemail = trim($subemail)) == 0){
         $form->setError($field, "* Email not entered");
      }
      else{
         /* Check if valid email address */
         $regex = "^[_+a-z0-9-]+(\.[_+a-z0-9-]+)*"
                 ."@[a-z0-9-]+(\.[a-z0-9-]{1,})*"
                 ."\.([a-z]{2,}){1}$";
         if(!eregi($regex,$subemail)){
            $form->setError($field, "* Email invalid");
         }
         $subemail = stripslashes($subemail);
      }

      /* Errors exist, have user correct them */
      if($form->num_errors > 0){
         return 1;  //Errors with form
      }
      /* No errors, add the new account to the */
      else{
         if($database->addNewUser($subuser, md5($subpass), $subemail)){
            if(EMAIL_WELCOME){
               $mailer->sendWelcome($subuser,$subemail,$subpass);
            }
            return 0;  //New user added succesfully
         }else{
            return 2;  //Registration attempt failed
         }
      }
   }
   
    function SessionMasterRegister($subuser, $subpass, $subemail){
	  
	  global $database, $form, $mailer;  //La base de datos, el formulario y el objeto del correo
      
      /* la comprobación de errores */
      $field = "user";  //Use field name for username
      if(!$subuser || strlen($subuser = trim($subuser)) == 0){
         $form->setError($field, "* Username not entered");
      }
      else{
         /* Arreglar nombre de usuario, revisar longitud */
         $subuser = stripslashes($subuser);
         if(strlen($subuser) < 5){
            $form->setError($field, "* Username below 5 characters");
         }
         else if(strlen($subuser) > 30){
            $form->setError($field, "* Username above 30 characters");
         }
         /* Compruebe si el nombre no es alfanumérico */
         else if(!eregi("^([0-9a-z])+$", $subuser)){
            $form->setError($field, "* Username not alphanumeric");
         }
         /* Compruebe si está reservado el nombre de usuario */
         else if(strcasecmp($subuser, GUEST_NAME) == 0){
            $form->setError($field, "* Username reserved word");
         }
         /* Compruebe si el nombre ya está en uso */
         else if($database->usernameTaken($subuser)){
            $form->setError($field, "* Username already in use");
         }
         /* Compruebe si está prohibido el usuario */
         else if($database->usernameBanned($subuser)){
            $form->setError($field, "* Username banned");
         }
      }

      /* la comprobación de errores de contraseña */
      $field = "pass";  //Utilice el nombre del campo de contraseña
      if(!$subpass){
         $form->setError($field, "* Password not entered");
      }
      else{
         /* Arreglar contraseña, y marca la longitud*/
         $subpass = stripslashes($subpass);
         if(strlen($subpass) < 4){
            $form->setError($field, "* Password too short");
         }
         /* Compruebe si la contraseña no es alfanumérico */
         else if(!eregi("^([0-9a-z])+$", ($subpass = trim($subpass)))){
            $form->setError($field, "* Password not alphanumeric");
         }
         /**
          * Note: I trimmed the password only after I checked the length
          * because if you fill the password field up with spaces
          * it looks like a lot more characters than 4, so it looks
          * kind of stupid to report "password too short".
          */
      }
      
      /* Email error checking */
      $field = "email";  //Use field name for email
      if(!$subemail || strlen($subemail = trim($subemail)) == 0){
         $form->setError($field, "* Email not entered");
      }
      else{
         /* Check if valid email address */
         $regex = "^[_+a-z0-9-]+(\.[_+a-z0-9-]+)*"
                 ."@[a-z0-9-]+(\.[a-z0-9-]{1,})*"
                 ."\.([a-z]{2,}){1}$";
         if(!eregi($regex,$subemail)){
            $form->setError($field, "* Email invalid");
         }
         $subemail = stripslashes($subemail);
      }

      /* Errors exist, have user correct them */
      if($form->num_errors > 0){
         return 1;  //Errors with form
      }
      /* No errors, add the new account to the */
      else{
	  //THE NAME OF THE CURRENT USER THE PARENT...
	  $parent = $this->username;
         if($database->addNewMaster($subuser, md5($subpass), $subemail, $parent)){
            if(EMAIL_WELCOME){
               $mailer->sendWelcome($subuser,$subemail,$subpass);
            }
            return 0;  //New user added succesfully
         }else{
            return 2;  //Registration attempt failed
         }
      }
   }
   
   
  function SessionMemberRegister($subuser, $subpass, $subemail){
	  
	  global $database, $form, $mailer;  //La base de datos, el formulario y el objeto del correo
      
      /* la comprobación de errores */
      $field = "user";  //Use field name for username
      if(!$subuser || strlen($subuser = trim($subuser)) == 0){
         $form->setError($field, "* Username not entered");
      }
      else{
         /* Arreglar nombre de usuario, revisar longitud */
         $subuser = stripslashes($subuser);
         if(strlen($subuser) < 5){
            $form->setError($field, "* Username below 5 characters");
         }
         else if(strlen($subuser) > 30){
            $form->setError($field, "* Username above 30 characters");
         }
         /* Compruebe si el nombre no es alfanumérico */
         else if(!eregi("^([0-9a-z])+$", $subuser)){
            $form->setError($field, "* Username not alphanumeric");
         }
         /* Compruebe si está reservado el nombre de usuario */
         else if(strcasecmp($subuser, GUEST_NAME) == 0){
            $form->setError($field, "* Username reserved word");
         }
         /* Compruebe si el nombre ya está en uso */
         else if($database->usernameTaken($subuser)){
            $form->setError($field, "* Username already in use");
         }
         /* Compruebe si está prohibido el usuario */
         else if($database->usernameBanned($subuser)){
            $form->setError($field, "* Username banned");
         }
      }

      /* la comprobación de errores de contraseña */
      $field = "pass";  //Utilice el nombre del campo de contraseña
      if(!$subpass){
         $form->setError($field, "* Password not entered");
      }
      else{
         /* Arreglar contraseña, y marca la longitud*/
         $subpass = stripslashes($subpass);
         if(strlen($subpass) < 4){
            $form->setError($field, "* Password too short");
         }
         /* Compruebe si la contraseña no es alfanumérico */
         else if(!eregi("^([0-9a-z])+$", ($subpass = trim($subpass)))){
            $form->setError($field, "* Password not alphanumeric");
         }
         /**
          * Nota: He recortado la contraseña sólo después de que nos
		  * la longitud ya que si se llena el campo de la contraseña
		  * con espacios que parece mucho más caracteres de 4, por lo
		  * que parece un poco estúpido mostrar "contraseña demasiado corta".
          */
      }
      
      /* la comprobación de errores de correo electrónico */
      $field = "email";  //Use el nombre de campo para el correo electrónico
      if(!$subemail || strlen($subemail = trim($subemail)) == 0){
         $form->setError($field, "* Email not entered");
      }
      else{
         /* Compruebe si la dirección de correo electrónico válida*/
         $regex = "^[_+a-z0-9-]+(\.[_+a-z0-9-]+)*"
                 ."@[a-z0-9-]+(\.[a-z0-9-]{1,})*"
                 ."\.([a-z]{2,}){1}$";
         if(!eregi($regex,$subemail)){
            $form->setError($field, "* Email invalid");
         }
         $subemail = stripslashes($subemail);
      }

      /* existir errores, usuario corrige */
      if($form->num_errors > 0){
         return 1;  //Errors with form
      }
      /*No hay errores, agregue la nueva cuenta a la */
      else{
	  //EL NOMBRE DEL PADRE COMÚN...
	  $parent = $this->username;
         if($database->addNewMember($subuser, md5($subpass), $subemail, $parent)){
            if(EMAIL_WELCOME){
               $mailer->sendWelcome($subuser,$subemail,$subpass);
            }
            return 0;  //nuevo usuario añadido correctamente
         }else{
            return 2;  //El registro ha fallado
         }
      }
   }
   
   
   function SessionAgentRegister($subuser, $subpass, $subemail){
	  
	  global $database, $form, $mailer;  //La base de datos, el formulario y el objeto del correo
      
      /* La comprobación de errores */
      $field = "user";  //Utilice el nombre del campo de nombre de usuario
      if(!$subuser || strlen($subuser = trim($subuser)) == 0){
         $form->setError($field, "* Username not entered");
      }
      else{
         /* Arreglar nombre de usuario, revisar longitud */
         $subuser = stripslashes($subuser);
         if(strlen($subuser) < 5){
            $form->setError($field, "* Username below 5 characters");
         }
         else if(strlen($subuser) > 30){
            $form->setError($field, "* Username above 30 characters");
         }
         /* Compruebe si el nombre no es alfanumérico */
         else if(!eregi("^([0-9a-z])+$", $subuser)){
            $form->setError($field, "* Username not alphanumeric");
         }
         /* Compruebe si está reservado el nombre de usuario */
         else if(strcasecmp($subuser, GUEST_NAME) == 0){
            $form->setError($field, "* Username reserved word");
         }
         /* Compruebe si el nombre ya está en uso*/
         else if($database->usernameTaken($subuser)){
            $form->setError($field, "* Username already in use");
         }
         /* Compruebe si está prohibido el Usuario */
         else if($database->usernameBanned($subuser)){
            $form->setError($field, "* Username banned");
         }
      }

      /* la comprobación de errores de contraseña */
      $field = "pass";  //Utilice el nombre del campo de contraseña
      if(!$subpass){
         $form->setError($field, "* La contraseña no funciono");
      }
      else{
         /* Arreglar contraseña y marca la longitud */
         $subpass = stripslashes($subpass);
         if(strlen($subpass) < 4){
            $form->setError($field, "* Contraseña demasiado corta");
         }
         /* Compruebe si la contraseña no es alfanumérica */
         else if(!eregi("^([0-9a-z])+$", ($subpass = trim($subpass)))){
            $form->setError($field, "* La contraseña no es alfanumérico");
         }
         /**
          * Nota: He recortado la contraseña sólo después
		  * de que nos da la longitud ya que si se llena el campo de la contraseña
		  * con espacios que parece mucho más caracteres de 4,
		  * por lo que parece un poco estúpido mostrar "contraseña demasiado corta".
          */
      }
      
      /* la comprobación de errores de correo electrónico */
      $field = "email";  //Use el nombre de campo para el correo electrónico
      if(!$subemail || strlen($subemail = trim($subemail)) == 0){
         $form->setError($field, "* Email not entered");
      }
      else{
         /* Compruebe si la dirección de correo electrónico válida */
         $regex = "^[_+a-z0-9-]+(\.[_+a-z0-9-]+)*"
                 ."@[a-z0-9-]+(\.[a-z0-9-]{1,})*"
                 ."\.([a-z]{2,}){1}$";
         if(!eregi($regex,$subemail)){
            $form->setError($field, "* Correo Invalido");
         }
         $subemail = stripslashes($subemail);
      }

      /* Si existen errores */
      if($form->num_errors > 0){
         return 1;  //Errores del formulario
      }
      /* No hay errores, agregue la nueva cuenta a la  */
      else{
	  //EL NOMBRE DEL PADRE COMÚN...
	  $parent = $this->username;
         if($database->addNewAgent($subuser, md5($subpass), $subemail, $parent)){
            if(EMAIL_WELCOME){
               $mailer->sendWelcome($subuser,$subemail,$subpass);
            }
            return 0;  //Usuario nuevo ha añadido correctamente
         }else{
            return 2;  //el intento registro falló
         }
      }
   }
   /**
    * editAccount - Los intentos para modificar la información de cuenta
	* del usuario que incluye la contraseña, la que primero se asegura es
	* correcta si se ha introducido, de ser así y la nueva contraseña está*
	* en el formato correcto, se realiza el cambio. Todos los demás campos
	* se cambian automáticamente.
    */
   function editAccount($subcurpass, $subnewpass, $subemail){
      global $database, $form;  //La base de datos y la forma de objeto
      /* Nueva contraseña introducida */
      if($subnewpass){
         /* la comprobación de errores contraseña actual */
         $field = "curpass";  //Utilice el nombre del campo de contraseña actual
         if(!$subcurpass){
            $form->setError($field, "* Current Password not entered");
         }
         else{
            /* Compruebe si la contraseña demasiado corta o no es alfanumérico */
            $subcurpass = stripslashes($subcurpass);
            if(strlen($subcurpass) < 4 ||
               !eregi("^([0-9a-z])+$", ($subcurpass = trim($subcurpass)))){
               $form->setError($field, "* La contraseña contiene caracteres incorrectos");
            }
            /* Contraseña introducida es incorrecta */
            if($database->confirmUserPass($this->username,md5($subcurpass)) != 0){
               $form->setError($field, "* La contraseña es incorrecta");
            }
         }
         
         /* Nueva comprobación de errores contraseña */
         $field = "newpass";  //Usar nombre de campo de nueva contraseña
         /* Arreglar contraseña, y marca la longitud */
         $subpass = stripslashes($subnewpass);
         if(strlen($subnewpass) < 4){
            $form->setError($field, "* La contraseña es muy corta");
         }
         /* Compruebe si la contraseña no es alfanumérico */
         else if(!eregi("^([0-9a-z])+$", ($subnewpass = trim($subnewpass)))){
            $form->setError($field, "* La contraseña tiene que ser alfanumerica");
         }
      }
      /* intento de cambio de contraseña */
      else if($subcurpass){
         /* Nuevo informe de errores de contraseña */
         $field = "newpass";  //Usar nombre de campo de nueva contraseña
         $form->setError($field, "* Nueva contraseña Actualizada!");
      }
      
      /* comprobación de errores de correo electrónico  */
      $field = "email";  //Use el nombre de campo para el correo electrónico
      if($subemail && strlen($subemail = trim($subemail)) > 0){
         /* Compruebe si la dirección de correo electrónico válida */
         $regex = "^[_+a-z0-9-]+(\.[_+a-z0-9-]+)*"
                 ."@[a-z0-9-]+(\.[a-z0-9-]{1,})*"
                 ."\.([a-z]{2,}){1}$";
         if(!eregi($regex,$subemail)){
            $form->setError($field, "* Correo Invalido");
         }
         $subemail = stripslashes($subemail);
      }
      
      /* De existir errores de usuario corregirlos */
      if($form->num_errors > 0){
         return false;
      }
      
      /* Actualizar la contraseña */
      if($subcurpass && $subnewpass){
         $database->updateUserField($this->username,"password",md5($subnewpass));
      }
      
      /* Cambiar e-mail */
      if($subemail){
         $database->updateUserField($this->username,"email",$subemail);
      }
      
      /* Éxito! */
      return true;
   }
   
   /**
    * isAdmin - Devuelve verdadero si el usuario conectado en la
	* actualidad es un administrador, en caso contrario
    */
   function isAdmin(){
      return ($this->userlevel == ADMIN_LEVEL ||
              $this->username  == ADMIN_NAME);
   }
   
    function isMaster(){
      return ($this->userlevel == MASTER_LEVEL);
   }
   
    function isAgent(){
      return ($this->userlevel == AGENT_LEVEL);
	}
   
    function isMember(){
      return ($this->userlevel == AGENT_MEMBER_LEVEL);
   }
   

   /**
    * generateRandID - Genera una cadena formada por letras aleatorios
	* (Minusculas y mayúsculas) y dígitos y devuelve el hash MD5
	* de que sea utilizado como un identificador de usuario.
    */
   function generateRandID(){
      return md5($this->generateRandStr(16));
   }
   
   /**
    * generateRandStr - Genera una cadena formada por letras aleatorios
	* (Minusculas y mayúsculas) y dígitos, la longitud es un parámetro especificado.
    */
   function generateRandStr($length){
      $randstr = "";
      for($i=0; $i<$length; $i++){
         $randnum = mt_rand(0,61);
         if($randnum < 10){
            $randstr .= chr($randnum+48);
         }else if($randnum < 36){
            $randstr .= chr($randnum+55);
         }else{
            $randstr .= chr($randnum+61);
         }
      }
      return $randstr;
   }
};


/**
 * Inicializar el objeto de sesión - Este debe ser
 * inicializado antes del objeto de formulario
 * porque el formulario utiliza variables de sesión,
 * que no se puede acceder a menos que la sesión ha comenzado.
 */
$session = new Session;

/* 	Inicializar el objeto de formato */
$form = new Form;

?>
