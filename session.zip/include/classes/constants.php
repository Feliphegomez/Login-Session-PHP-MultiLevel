<?php
define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PASS", "tucontraseña");
define("DB_NAME", "deMedallo.com");

/** 
 * Restricciones de tabla de base de datos - 
 * Estas constantes tienen los nombres de todas las tablas de base de datos utilizados 
 * en el guión. 
**/
 
define("TBL_USERS", "users");
define("TBL_ACTIVE_USERS",  "active_users");
define("TBL_ACTIVE_GUESTS", "active_guests");
define("TBL_BANNED_USERS",  "banned_users");

/**
  * Los nombres especiales y constantes de nivel - el administrador 
  * de la página sólo será accesible para el usuario con el nombre
  * de administrador y los usuarios también a aquellos a nivel de
  * usuario de administración. Siente libre de cambiar los nombres y
  * las constantes denivel como mejor le parezca, también puede
  * añadir las especificaciones de nivel adicionales.
  * Los niveles deben estar entre 0-9 dígitos.
 */
define("ADMIN_NAME", "admin");    //1. control de administración de todo
define("GUEST_NAME", "Guest");   
define("ADMIN_LEVEL", 9);        // 2. administrador de nivel .. controlar el maestro
define("MASTER_LEVEL", 8);       // 3. maestro de nivel .. control maestro del agente
define("AGENT_LEVEL",  1);       // 4. nivel del agente .. agente de control del miembro
define("AGENT_MEMBER_LEVEL", 2); // 5. miembro de nivel del agente de control .. miembro de su / su propia cuenta
define("GUEST_LEVEL", 0);        // 6. invitados .. nivel para huéspedes controlarse

/**
 * Este boolean controla constantes si la secuencia de comandos realiza un 
 * seguimiento de la actividad de usuarios activos e invitados que visitan el sitio.
 */
define("TRACK_VISITORS", true);

/**
  * Constantes Time Out - Estas limitaciones se refieren a la cantidad máxima de tiempo (en minutos) 
  * después de su última página Que fresco el usuario y el invitado se siguen considerando visitantes activos.
 */
define("USER_TIMEOUT", 10);
define("GUEST_TIMEOUT", 5);

/**
 * Cookie Constants - these are the parameters
 * Constantes de la Cookie - Estos son los parámetros a la llamada 
 * de la función setcookie, cambiarlos si es necesario para adaptarse 
 * a su sitio web. Si necesita ayuda, visite www.php.net para obtener más información.
 * <http://www.php.net/manual/en/function.setcookie.php>
 */
// define("COOKIE_EXPIRE", 60*60*24*30);  //30 días
define("COOKIE_EXPIRE", 60*60*24*100);  //100 días de forma predeterminada
define("COOKIE_PATH", "/");  //Disponibles en el dominio entero

/**
 * Constantes de correo electrónico - que se especifican lo que sucede
 * en el campo de los correos electrónicos que envía la secuencia de comandos 
 * para los usuarios, y si se debe enviar un mensaje de bienvenida a los nuevos
 * usuarios registrados.
 */
define("EMAIL_FROM_NAME", "ANDRES FELIPE GOMEZ MAYA");
define("EMAIL_FROM_ADDR", "feliphegomez@demedallo.com");
define("EMAIL_WELCOME", false);

/**
 * Esta constante fuerzas de todos los usuarios tengan
 * nombres de usuario en minúsculas, mayúsculas se convierten automáticamente.
 */
define("ALL_LOWERCASE", false);
?>
