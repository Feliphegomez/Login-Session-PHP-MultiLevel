<?php
include("constants.php");
      
class MySQLDB
{
   var $connection;         //La conexión de base de datos MySQL
   var $num_active_users;   //úmero de Usuarios Activos Visualizacion del Sitio
   var $num_active_guests;  //Número de huéspedes más activos ver el sitio
   var $num_members;        //Número de usuarios suscritos
   /* Nota: Los miembros llaman getNumMembers() para acceder a $num_members! */

   /* constructor de la clase */
   function MySQLDB(){
      /*Haga la conexión a la base de datos */
      $this->connection = mysql_connect(DB_SERVER, DB_USER, DB_PASS) or die(mysql_error());
      mysql_select_db(DB_NAME, $this->connection) or die(mysql_error());
      
      /**
       * Sólo consultar la base de datos para averiguar cuando el número de miembros getNumMembers() es llamado por primera vez, hasta entonces, establece el valor predeterminado.
       */
	   
      $this->num_members = -1;
      
      if(TRACK_VISITORS){
         /* Calcular el número de usuarios en el sitio */
         $this->calcNumActiveUsers();
      
         /* Calcular el número de invitados en el sitio */
         $this->calcNumActiveGuests();
      }
   }

   /**
    * confirmUserPass - Comprueba si el nombre de usuario dado
	* está en la base de datos, de ser así, se comprueba si la
	* contraseña proporcionada es la misma contraseña en la base
	* de datos para ese usuario. Si el usuario no existe o si las
	* contraseñas no coinciden, devuelve un código de error (1 o 2).
	* En caso de éxito se devuelve 0.
    */
   function confirmUserPass($username, $password){
      /* Add slashes si es necesario (para consulta) */
      if(!get_magic_quotes_gpc()) {
	      $username = addslashes($username);
      }

      /* Compruebe que el usuario está en la base de datos */
      $q = "SELECT password FROM ".TBL_USERS." WHERE username = '$username'";
      $result = mysql_query($q, $this->connection);
      if(!$result || (mysql_numrows($result) < 1)){
         return 1; // Nombre de usuario indica el fracaso
      }

      /* Recuperar la contraseña del resultado */
      $dbarray = mysql_fetch_array($result);
      $dbarray['password'] = stripslashes($dbarray['password']);
      $password = stripslashes($password);

      /* Validar que la contraseña es correcta */
      if($password == $dbarray['password']){
         return 0; // Éxito! Nombre de usuario y la contraseña confirmada
      }
      else{
         return 2; // Contraseña indica el fracaso
      }
   }
   
   /**
    * confirmUserID - Comprueba si el nombre de usuario dado está en la base de datos, 
	* de ser así, se comprueba si el ID de usuario ID de usuario dado es la misma en la 
	* base de datos para ese usuario. Si el usuario no existe o si los identificadores de
	* usuario no coinciden, devuelve un código de error (1 o 2). En caso de éxito se devuelve 0.
    */
   function confirmUserID($username, $userid){
      /* Add slashes si es necesario (para consulta) */
      if(!get_magic_quotes_gpc()) {
	      $username = addslashes($username);
      }

      /* Compruebe que el usuario está en la base de datos */
      $q = "SELECT userid FROM ".TBL_USERS." WHERE username = '$username'";
      $result = mysql_query($q, $this->connection);
      if(!$result || (mysql_numrows($result) < 1)){
         return 1; //Indicates username failure
      }

      /* Recuperar identificador de usuario desde consecuencia */
      $dbarray = mysql_fetch_array($result);
      $dbarray['userid'] = stripslashes($dbarray['userid']);
      $userid = stripslashes($userid);

      /* Validar que id de usuario es correcta */
      if($userid == $dbarray['userid']){
         return 0; //¡Éxito! Nombre de usuario y la ID de usuario confirmó
      }
      else{
         return 2; //Indica la identificación del usuario no fue válida
      }
   }
   
   /**
    * usernameTaken - Devuelve verdadero si el nombre de usuario
	* ha sido tomado por otro usuario.
    */
   function usernameTaken($username){
      if(!get_magic_quotes_gpc()){
         $username = addslashes($username);
      }
      $q = "SELECT username FROM ".TBL_USERS." WHERE username = '$username'";
      $result = mysql_query($q, $this->connection);
      return (mysql_numrows($result) > 0);
   }
   
   /**
    * usernameBanned - Devuelve verdadero si el nombre de usuario 
	* ha sido prohibido por el administrador..
    */
   function usernameBanned($username){
      if(!get_magic_quotes_gpc()){
         $username = addslashes($username);
      }
      $q = "SELECT username FROM ".TBL_BANNED_USERS." WHERE username = '$username'";
      $result = mysql_query($q, $this->connection);
      return (mysql_numrows($result) > 0);
   }
   
   /**
    * addNewUser - Inserta el (nombre de usuario, contraseña, correo electrónico) 
	* información en la base de datos dada. nivel de usuario correspondiente se establece. 
	* Devuelve verdadero cuando finaliza correctamente, false en caso contrario.
    */
   function addNewUser($username, $password, $email){
      $time = time();
      /* Si administrador inscribirse, dan a nivel de usuario administrador */
      if(strcasecmp($username, ADMIN_NAME) == 0){
         $ulevel = ADMIN_LEVEL;
      }else{
         $ulevel = MASTER_LEVEL;
      }
      $q = "INSERT INTO ".TBL_USERS." VALUES ('$username', '$password', '0', $ulevel, '$email', $time)";
      return mysql_query($q, $this->connection);
   }
   
   //añadir nuevo Master
   function addNewMaster($username, $password, $email, $parent_directory){
  
      $time = time();
      $ulevel = MASTER_LEVEL;   //8
      $q = "INSERT INTO ".TBL_USERS." VALUES ('$username', '$password', '0', $ulevel, '$email', $time, '$parent_directory')";
      return mysql_query($q, $this->connection); 
   }
   
   
   //añadir nuevo Usu
   function addNewAgent($username, $password, $email, $parent_directory){
 
      $time = time();
      $ulevel = AGENT_LEVEL;   //2
      $q = "INSERT INTO ".TBL_USERS." VALUES ('$username', '$password', '0', $ulevel, '$email', $time, '$parent_directory')";
      return mysql_query($q, $this->connection); 
   }
   
   //añadir nuevo miembro
   function addNewMember($username, $password, $email, $parent_directory){
   
      $time = time();
      $ulevel = AGENT_MEMBER_LEVEL;
       $q = "INSERT INTO ".TBL_USERS." VALUES ('$username', '$password', '0', $ulevel, '$email', $time, '$parent_directory')";
      return mysql_query($q, $this->connection); 
   }
   
   /**
    * updateUserField - Actualiza un campo especificado por el parámetro de campo, 
	* en la fila del usuario de la base de datos.
    */
   function updateUserField($username, $field, $value){
      $q = "UPDATE ".TBL_USERS." SET ".$field." = '$value' WHERE username = '$username'";
      return mysql_query($q, $this->connection);
   }
   
   /**
    * getUserInfo - Devuelve la matriz resultado de una consulta mysql solicitando
	* toda la información almacenada en relación con el nombre de usuario dado.
	* Si consulta falla, se devuelve NULL.
    */
   function getUserInfo($username){
      $q = "SELECT * FROM ".TBL_USERS." WHERE username = '$username'";
      $result = mysql_query($q, $this->connection);
      /* Ha producido un error, de retorno dado nombre  */
      if(!$result || (mysql_numrows($result) < 1)){
         return NULL;
      }
      /* array resultante de retorno */
      $dbarray = mysql_fetch_array($result);
      return $dbarray;
   }
   
      function getUserOnly($username){
      $q = "SELECT username FROM ".TBL_USERS." WHERE username = '$username'";
      $result = mysql_query($q, $this->connection);
      /* Ha producido un error, de retorno dado nombre */
      if(!$result || (mysql_numrows($result) < 1)){
         return NULL;
      }
      /* array resultante de retorno */
      $dbarray = mysql_fetch_array($result);
      return $dbarray;
   }
   
   /**
    * getNumMembers - Devuelve el número de usuarios suscritos en
	* marcha de la página web, los miembros prohibidos no incluidos. La primera vez que se invoca
	* la función de carga en la página, se consulta la base, en llamadas posteriores, se devuelve
	* el resultado almacenado. Esto es para mejorar la eficiencia, la eficacia es no consultar
	* la base de datos cuando no se realiza ninguna llamada.
    */
   function getNumMembers(){
      if($this->num_members < 0){
         $q = "SELECT * FROM ".TBL_USERS;
         $result = mysql_query($q, $this->connection);
         $this->num_members = mysql_numrows($result);
      }
      return $this->num_members;
   }
   
   /**
    * calcNumActiveUsers - Se entera de la cantidad de usuarios activos que están viendo el sitio
	* y establecer variable de clase en consecuencia.
    */
   function calcNumActiveUsers(){
      /* Calcular el número de usuarios en el sitio */
      $q = "SELECT * FROM ".TBL_ACTIVE_USERS;
      $result = mysql_query($q, $this->connection);
      $this->num_active_users = mysql_numrows($result);
   }
   
   /**
    * calcNumActiveGuests - Descubre cómo muchas personas activas están viendo sitio
	* y establecer variable de clase en consecuencia.
    */
   function calcNumActiveGuests(){
      /* Calcular el número de personas en el sitio */
      $q = "SELECT * FROM ".TBL_ACTIVE_GUESTS;
      $result = mysql_query($q, $this->connection);
      $this->num_active_guests = mysql_numrows($result);
   }
   
   /**
    * addActiveUser - Actualizaciones nombres de usuario duran
	* marca de tiempo activo en la base de datos, y también le
	* agrega a la tabla de usuarios activos, o actualizaciones
	* de marca de tiempo si ya están allí.
    */
   function addActiveUser($username, $time){
      $q = "UPDATE ".TBL_USERS." SET timestamp = '$time' WHERE username = '$username'";
      mysql_query($q, $this->connection);
      
      if(!TRACK_VISITORS) return;
      $q = "REPLACE INTO ".TBL_ACTIVE_USERS." VALUES ('$username', '$time')";
      mysql_query($q, $this->connection);
      $this->calcNumActiveUsers();
   }
   
   /* addActiveGuest - Añade invitados a la mesa activa huéspedes */
   function addActiveGuest($ip, $time){
      if(!TRACK_VISITORS) return;
      $q = "REPLACE INTO ".TBL_ACTIVE_GUESTS." VALUES ('$ip', '$time')";
      mysql_query($q, $this->connection);
      $this->calcNumActiveGuests();
   }
   
   /* Estas funciones son explica por sí mismo, sin necesidad de comentarios */
   
   /* removeActiveUser */
   function removeActiveUser($username){
      if(!TRACK_VISITORS) return;
      $q = "DELETE FROM ".TBL_ACTIVE_USERS." WHERE username = '$username'";
      mysql_query($q, $this->connection);
      $this->calcNumActiveUsers();
   }
   
   /* removeActiveGuest */
   function removeActiveGuest($ip){
      if(!TRACK_VISITORS) return;
      $q = "DELETE FROM ".TBL_ACTIVE_GUESTS." WHERE ip = '$ip'";
      mysql_query($q, $this->connection);
      $this->calcNumActiveGuests();
   }
   
   /* removeInactiveUsers */
   function removeInactiveUsers(){
      if(!TRACK_VISITORS) return;
      $timeout = time()-USER_TIMEOUT*60;
      $q = "DELETE FROM ".TBL_ACTIVE_USERS." WHERE timestamp < $timeout";
      mysql_query($q, $this->connection);
      $this->calcNumActiveUsers();
   }

   /* removeInactiveGuests */
   function removeInactiveGuests(){
      if(!TRACK_VISITORS) return;
      $timeout = time()-GUEST_TIMEOUT*60;
      $q = "DELETE FROM ".TBL_ACTIVE_GUESTS." WHERE timestamp < $timeout";
      mysql_query($q, $this->connection);
      $this->calcNumActiveGuests();
   }
   
   /**
    * query - Realiza la consulta dada en la base de datos y devuelve el resultado,
	* que puede ser falsa, verdadera o un identificador de recursos.
    */
   function query($query){
      return mysql_query($query, $this->connection);
   }
};

/* Creación de una conexión de base de datos */
$database = new MySQLDB;

?>
