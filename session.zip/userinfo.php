<?php
include("include/classes/session.php");
?>

<html>
<body>

<?php
/* Nombre de usuario solicitado la comprobación de errores */
$req_user = trim($_GET['user']);
if(!$req_user || strlen($req_user) == 0 ||
   !eregi("^([0-9a-z])+$", $req_user) ||
   !$database->usernameTaken($req_user)){
   die("Username not registered");
}

/* Usuario conectado visualización cuenta propia */
if(strcmp($session->username,$req_user) == 0){
   echo "<h1>My Account</h1>";
}
/* Visitante no se están viendo cuenta propia */
else{
   echo "<h1>User Info</h1>";
}

/* Pantalla solicitado información de los usuarios */
$req_user_info = $database->getUserInfo($req_user);

/* Nombre de usuario */
echo "<b>Username: ".$req_user_info['username']."</b><br>";

/* Email */
echo "<b>Email:</b> ".$req_user_info['email']."<br>";

/**
 * Nota: cuando se agrega sus propios campos a la tabla 
 * de usuarios para contener más información, como la página 
 * de inicio, ubicación, etc. que se puede acceder fácilmente 
 * por la red de información del usuario.
 *
 * $session->user_info['location']; (for logged in users)
 *
 * ..y para esta página,
 *
 * $req_user_info['location']; (para cualquier usuario)
 */

/* Si ha iniciado sesión en el usuario que está viendo cuenta propia, dará enlace para editar */
if(strcmp($session->username,$req_user) == 0){
   echo "<br><a href=\"useredit.php\">Editar mi informacion</a><br>";
}

/* Link back to main */
echo "<br>Volver al menu [<a href=\"index.php\">Princiapl</a>]<br>";

?>

</body>
</html>
