<?php
include("include/classes/session.php");

class Process
{
   /* constructor de la clase */
   function Process(){
      global $session;
      /* formulario de acceso enviado por los usuarios */
      if(isset($_POST['sublogin'])){
         $this->procLogin();
      }
      /* formulario de registro enviado por los usuarios */
      else if(isset($_POST['subjoin'])){
         $this->procRegister();
      }
	  
	  /* formulario de registro enviado por los miembros */
      else if(isset($_POST['member_subjoin'])){
         $this->procMemberRegister();
      }
	  
	      /* formulario de registro enviado por los master */
      else if(isset($_POST['master_subjoin'])){
         $this->procMasterRegister();
      }
	  
	      /* formulario de registro enviado por los agentes */
      else if(isset($_POST['agent_subjoin'])){
         $this->procAgentRegister();
      }
	  
      /* Usuario presentado olvidó formulario de contraseña */
      else if(isset($_POST['subforgot'])){
         $this->procForgotPass();
      }
      /* Usuario presentado edición formulario de cuenta */
      else if(isset($_POST['subedit'])){
         $this->procEditAccount();
      }
      /**
       * La única razón por de volver a cargar esta pagina 
	   * es si quiere cerrar la sesión, lo que significa que
	   * el usuario ha iniciado sesión la actualidad.
       */
      else if($session->logged_in){
         $this->procLogout();
      }
      /**
       * No debe llegar hasta aquí, lo que significa que el usuario
	   * está viendo esta página por error y, por tanto, se redirige.
       */
       else{
          header("Location: main.php");
       }
   }

   /**
    * procLogin - Procesa el formulario de acceso enviado por el usuario,
	* si se encuentran errores, se redirige al usuario a corregir la
	* información, si no es así, el usuario está conectado de manera
	* efectiva en el sistema.
    */
   function procLogin(){
      global $session, $form;
      /* Intento de inicio de sesión */
      $retval = $session->login($_POST['user'], $_POST['pass'], isset($_POST['remember']));
      
      /* Inicio de sesión correcto */
      if($retval){
         header("Location: ".$session->referrer);
      }
      /* error de inicio de sesion */
      else{
         $_SESSION['value_array'] = $_POST;
         $_SESSION['error_array'] = $form->getErrorArray();
         header("Location: ".$session->referrer);
      }
   }
   
   /**
    * procLogout - Simplemente intenta iniciar sesión el usuario del sistema,
	* dado que no hay de formulario de cierre de sesión para procesar.
    */
   function procLogout(){
      global $session;
      $retval = $session->logout();
      header("Location: main.php");
   }
   
   /**
    * procRegister - Procesa el formulario de registro enviado por el usuario,
	* si se encuentran errores, se redirige al usuario a corregir la información,
	* si no es así, el usuario se ha registrado de manera efectiva con el sistema
	* y es un correo electrónico (opcional) enviado al usuario recién creado.
    */
   function procRegister(){
      global $session, $form;
      /* Convertir nombre de usuario para todas las minúsculas (por la opción) */
      if(ALL_LOWERCASE){
         $_POST['user'] = strtolower($_POST['user']);
      }
      /* intento de registro */
      $retval = $session->register($_POST['user'], $_POST['pass'], $_POST['email']);
      
      /* Registration Successful */
      if($retval == 0){
         $_SESSION['reguname'] = $_POST['user'];
         $_SESSION['regsuccess'] = true;
         header("Location: ".$session->referrer);
      }
      /* Error encontrado */
      else if($retval == 1){
         $_SESSION['value_array'] = $_POST;
         $_SESSION['error_array'] = $form->getErrorArray();
         header("Location: ".$session->referrer);
      }
      /* intento de registro Fallo */
      else if($retval == 2){
         $_SESSION['reguname'] = $_POST['user'];
         $_SESSION['regsuccess'] = false;
         header("Location: ".$session->referrer);
      }
   }
   
    function procMasterRegister(){
      global $session, $form;
      /* Convertir nombre de usuario para todas las minúsculas (por la opción) */
      if(ALL_LOWERCASE){
         $_POST['user'] = strtolower($_POST['user']);
      }
      /* intento de registro */
      $retval = $session->SessionMasterRegister($_POST['user'], $_POST['pass'], $_POST['email']);
      
      /* Registration Successful */
      if($retval == 0){
         $_SESSION['reguname'] = $_POST['user'];
         $_SESSION['regsuccess'] = true;
         header("Location: ".$session->referrer.'?'.$session->username);
      }
      /* Error encontrado */
      else if($retval == 1){
         $_SESSION['value_array'] = $_POST;
         $_SESSION['error_array'] = $form->getErrorArray();
         header("Location: ".$session->referrer.'?'.$session->username);
      }
      /* intento de registro Fallo */
      else if($retval == 2){
         $_SESSION['reguname'] = $_POST['user'];
         $_SESSION['regsuccess'] = false;
         header("Location: ".$session->referrer.'?'.$session->username);
      }
   }
   
   
   
    function procMemberRegister(){
      global $session, $form;
      /* Convertir nombre de usuario para todas las minúsculas (por la opción) */
      if(ALL_LOWERCASE){
         $_POST['user'] = strtolower($_POST['user']);
      }
      /* intento de registro */
      $retval = $session->SessionMemberRegister($_POST['user'], $_POST['pass'], $_POST['email']);
      
      /* Registration Successful */
      if($retval == 0){
         $_SESSION['reguname'] = $_POST['user'];
         $_SESSION['regsuccess'] = true;
         header("Location: ".$session->referrer.'?'.$session->username);
      }
      /* Error encontrado */
      else if($retval == 1){
         $_SESSION['value_array'] = $_POST;
         $_SESSION['error_array'] = $form->getErrorArray();
         header("Location: ".$session->referrer.'?'.$session->username);
      }
      /* intento de registro Fallo */
      else if($retval == 2){
         $_SESSION['reguname'] = $_POST['user'];
         $_SESSION['regsuccess'] = false;
         header("Location: ".$session->referrer.'?'.$session->username);
      }
   }
   
      
    function procAgentRegister(){
      global $session, $form;
      /* Convertir nombre de usuario para todas las minúsculas (por la opción) */
      if(ALL_LOWERCASE){
         $_POST['user'] = strtolower($_POST['user']);
      }
      /* intento de registro */
      $retval = $session->SessionAgentRegister($_POST['user'], $_POST['pass'], $_POST['email']);
      
      /* Registration Successful */
      if($retval == 0){
         $_SESSION['reguname'] = $_POST['user'];
         $_SESSION['regsuccess'] = true;
         header("Location: ".$session->referrer.'?'.$session->username);
      }
      /* Error encontrado */
      else if($retval == 1){
         $_SESSION['value_array'] = $_POST;
         $_SESSION['error_array'] = $form->getErrorArray();
         header("Location: ".$session->referrer.'?'.$session->username);
      }
      /* intento de registro Fallo */
      else if($retval == 2){
         $_SESSION['reguname'] = $_POST['user'];
         $_SESSION['regsuccess'] = false;
         header("Location: ".$session->referrer.'?'.$session->username);
      }
   }
   /**
    * procForgotPass - Valida el nombre de usuario dado a continuación,
	* si todo está bien, una nueva contraseña se genera y se envía por
	* correo electrónico a la dirección que el usuario ha dado de registro.
    */
   function procForgotPass(){
      global $database, $session, $mailer, $form;
      /* la comprobación de errores Nombre de usuario */
      $subuser = $_POST['user'];
      $field = "user";  //Use field name for username
      if(!$subuser || strlen($subuser = trim($subuser)) == 0){
         $form->setError($field, "* Username not entered<br>");
      }
      else{
         /* Comprobar que el user esté en la de base de datos */
         $subuser = stripslashes($subuser);
         if(strlen($subuser) < 5 || strlen($subuser) > 30 ||
            !eregi("^([0-9a-z])+$", $subuser) ||
            (!$database->usernameTaken($subuser))){
            $form->setError($field, "* Username does not exist<br>");
         }
      }
      
      /* existir errores, han de usuario corregirlos */
      if($form->num_errors > 0){
         $_SESSION['value_array'] = $_POST;
         $_SESSION['error_array'] = $form->getErrorArray();
      }
      /* Generar nueva contraseña y enviarla por correo electrónico al usuario */
      else{
         /* Generar nueva contraseña */
         $newpass = $session->generateRandStr(8);
         
         /* Obtener correo electrónico del usuario */
         $usrinf = $database->getUserInfo($subuser);
         $email  = $usrinf['email'];
         
         /* Intentará enviar el correo electrónico con una nueva contraseña */
         if($mailer->sendNewPass($subuser,$email,$newpass)){
            /* El correo electrónico enviado y base de datos  actualizada*/
            $database->updateUserField($subuser, "password", md5($newpass));
            $_SESSION['forgotpass'] = true;
         }
         /* Si fracasa el correo electrónico, no cambia la contraseña */
         else{
            $_SESSION['forgotpass'] = false;
         }
      }
      
      header("Location: ".$session->referrer);
   }
   
   /**
    * procEditAccount - Los intentos de modificar la información de la cuenta del usuario,
	* incluyendo la contraseña, que debe ser verificada antes de que se realice un cambio.
    */
   function procEditAccount(){
      global $session, $form;
      /* Editar cuenta */
      $retval = $session->editAccount($_POST['curpass'], $_POST['newpass'], $_POST['email']);

      /* Cuenta editada con exito */
      if($retval){
         $_SESSION['useredit'] = true;
         header("Location: ".$session->referrer);
      }
      /* Error encontrado */
      else{
         $_SESSION['value_array'] = $_POST;
         $_SESSION['error_array'] = $form->getErrorArray();
         header("Location: ".$session->referrer);
      }
   }
};

/* Inicializar Process */
$process = new Process;

?>
